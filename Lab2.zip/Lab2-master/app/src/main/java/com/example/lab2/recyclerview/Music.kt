package com.example.lab2.recyclerview

data class Music(
    val name: String,
    val singer: String
)
